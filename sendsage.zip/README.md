# SendSage
AI-powered Email Warm-Up & Deliverability Optimizer

## Monorepo Structure
- apps/dashboard: Frontend (Next.js)
- apps/api: Backend API (Express)
- services/*: Background jobs (warm-up, AI analysis)
- prisma: PostgreSQL schema

## Dev Setup
```bash
yarn install
yarn dev (to start both frontend and backend)
```

## Deployment Stack
- Vercel (Frontend)
- Render/Railway (Backend)
- Supabase (PostgreSQL)
