export function queueWarmupJob(email: string) {
  console.log(`Queued warm-up job for ${email}`);
}