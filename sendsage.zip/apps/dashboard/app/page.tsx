export default function HomePage() {
  return <div className="text-xl">Welcome to SendSage 🚀</div>;
}